#
# Copyright 2022 DMetaSoul
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import argparse
import yaml
import cattrs


from metaspore.algos.pipeline import InitSparkModule, InitSparkConfig
from metaspore.algos.pipeline import DataLoaderModule, DataLoaderConfig
from metaspore.algos.pipeline import DeepCTRModule
from metaspore.algos.pipeline import setup_logging

def notify_consul(estimator_params):
    import json
    import consul

    print(estimator_params)

    consul_host = estimator_params['consul_host']
    consul_port = estimator_params['consul_port']
    consul_endpoint_prefix = estimator_params['consul_endpoint_prefix']
    consul_model_sync_command = estimator_params['consul_model_sync_command']

    experiment_name = estimator_params['experiment_name']
    model_export_path = estimator_params['model_export_path']
    model_version = estimator_params['model_version']

    data = {
        'name': experiment_name,
        'service': experiment_name + '-service',
        'path': model_export_path,
        'version': model_version,
        'util_cmd': consul_model_sync_command,
    }
    string = json.dumps(data, separators=(',', ': '), indent=4)

    consul_client = consul.Consul(host=consul_host, port=consul_port)
    index, response = consul_client.kv.get(consul_endpoint_prefix, keys=True)
    if response is None:
        consul_client.kv.put(consul_endpoint_prefix + '/', value=None)
        print("init consul endpoint dir: %s" % consul_endpoint_prefix)
    endpoint = '%s/%s' % (consul_endpoint_prefix, experiment_name)
    consul_path = f'{consul_host}:{consul_port}/{endpoint}'
    try:
        consul_client.kv.put(endpoint, string)
        message = f"notify consul succeed: {consul_path}"
        print(message)
    except consul.Timeout as err:
        raise TimeoutError(f"notify consul {consul_path} timeout err: {err}") from err

def subst(spec):
    from config_helpers import subst_value
    params = spec['dataset']
    keys = 'train_path', 'test_path'
    for key in keys:
        params[key] = subst_value(params[key])
    params = spec['training']['estimator_params']
    keys = 'model_in_path', 'model_out_path', 'model_export_path', 'model_version', 'experiment_name'
    for key in keys:
        params[key] = subst_value(params[key])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--conf', type=str, required=True)
    args = parser.parse_args()

    spec = dict()
    with open(args.conf, 'r') as stream:
        yaml_dict = yaml.load(stream, Loader=yaml.FullLoader)
        spec = yaml_dict['spec']

    subst(spec)
    setup_logging(**spec['logging'])

    # 1. init spark
    initSparkModule = InitSparkModule(cattrs.structure(spec['spark'], InitSparkConfig))
    spark, worker_count, server_count = initSparkModule.run()

    # 2. load dataset
    dataLoaderModule = DataLoaderModule(cattrs.structure(spec['dataset'], DataLoaderConfig), spark)
    dataset_dict = dataLoaderModule.run()

    # 3. train, predict and evaluate
    deepCTRModule = DeepCTRModule(spec['training'])
    metric_dict = deepCTRModule.run(dataset_dict['train'], dataset_dict.get('test'), worker_count, server_count)

    # 4. notify consul
    # TODO: use PyTorchModel.publish to notify consul
    # TODO: implement notify model loading
    #notify_consul(spec['training']['estimator_params'])

    # 5. stop spark session
    spark.stop()
