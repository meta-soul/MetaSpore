def subst_value(string):
    import os
    if string is None:
        return None
    s3_work_dir = os.environ['METASPORE_FLOW_S3_WORK_DIR'].rstrip('/')
    scene_name = os.environ['METASPORE_FLOW_SCENE_NAME']
    model_name = os.environ['METASPORE_FLOW_MODEL_NAME']
    model_version = os.environ['METASPORE_FLOW_MODEL_VERSION']
    last_model_version = os.environ.get('METASPORE_FLOW_LAST_MODEL_VERSION')
    if last_model_version is None and (
       '@{METASPORE_FLOW_LAST_MODEL_VERSION}' in string or
       '@METASPORE_FLOW_LAST_MODEL_VERSION' in string):
        return None
    string = string.replace('@{METASPORE_FLOW_S3_WORK_DIR}', s3_work_dir)
    string = string.replace('@{METASPORE_FLOW_SCENE_NAME}', scene_name)
    string = string.replace('@{METASPORE_FLOW_MODEL_NAME}', model_name)
    string = string.replace('@{METASPORE_FLOW_MODEL_VERSION}', model_version)
    if last_model_version is not None:
        string = string.replace('@{METASPORE_FLOW_LAST_MODEL_VERSION}', last_model_version)
    string = string.replace('@METASPORE_FLOW_S3_WORK_DIR', s3_work_dir)
    string = string.replace('@METASPORE_FLOW_SCENE_NAME', scene_name)
    string = string.replace('@METASPORE_FLOW_MODEL_NAME', model_name)
    string = string.replace('@METASPORE_FLOW_MODEL_VERSION', model_version)
    if last_model_version is not None:
        string = string.replace('@METASPORE_FLOW_LAST_MODEL_VERSION', last_model_version)
    return string
